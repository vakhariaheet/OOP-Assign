#include <iostream>

using namespace std;

int main() {
     int num1, num2;
     cout << "Enter two numbers: ";
     cin >> num1 >> num2;
     cout << "Sum Of " << num1 << " and " << num2<<" is " << num1 + num2;
     cout << "Diff Of " << num1 << " and " << num2<<" is " << num1 - num2;
     cout << "Quotient Of " << num1 << " and " << num2<<" is " << num1 / num2;
     cout << "Product Of " << num1 << " and " << num2<<" is " << num1 * num2;
     cout << "Reminder Of " << num1 << " and " << num2<<" is " << num1 % num2;

}